#include <stdio.h>

int soma(int n){
    if(n==1)return 1;
    else return n+soma(n-1);

}
int main() {
//Fa�a uma fun��o recursiva que calcula a soma dos n�meros de 1 at� n.
    int n;
    scanf("%d",&n);
    printf("%d",soma(n));

    return 0;
}
