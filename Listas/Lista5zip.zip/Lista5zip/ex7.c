#include <stdio.h>
#include <string.h>
#include <ctype.h>

int valores(int a){
    if(a==0)return 0;
    else return a%10+valores(a/10);


}


int main(){
//Fa�a uma fun��o para encontrar a soma dos d�gitos de um n�mero usando recurs�o. Fa�a um programa principal que leia um n�mero, acione a fun��o e exiba o resultado gerado.



    int n;
    scanf("%d",&n);
    printf("%d",valores(n));
    return 0;
}
