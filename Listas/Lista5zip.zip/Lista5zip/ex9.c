#include <stdio.h>

int resto(int numerador, int denominador) {
    if (numerador < denominador)      // caso base: n�o d� para subtrair mais
        return numerador;             // o que sobra � o resto
    else
        return resto(numerador - denominador, denominador); // subtra��o + recurs�o
}

int main() {
    int a, b;
    scanf("%d", &a);
    scanf("%d", &b);

    printf("%d", resto(a, b));


    return 0;
}
